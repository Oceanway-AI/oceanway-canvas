import { useRef, useState, type KeyboardEvent, type ReactNode } from 'react'

import './style.css'

export interface PickerGroup<T> {
  key: string
  label: string
  options: T[]
}
export interface PickerSeries<T> {
  key: string
  label: string
  icon?: ReactNode
  groups: PickerGroup<T>[]
}

export interface ModelPickerPanelProps<T> {
  series: PickerSeries<T>[]
  layout: 'media' | 'text' | 'variants'
  labels: {
    search: string
    placeholder: string
    series: string
    models: string
    variants: string
    back: string
    empty: string
    noMatches?: string
  }
  isSelected: (option: T) => boolean
  keywords: (option: T) => readonly string[]
  renderOption: (option: T, group: PickerGroup<T>) => ReactNode
  renderGroupHeading?: (group: PickerGroup<T>) => ReactNode
  optionRole?: 'listbox' | 'group'
  notice?: ReactNode
}

// Mount once per opening so a new visit starts at the host's current selection.
export function ModelPickerPanel<T>(props: ModelPickerPanelProps<T>) {
  const { series, labels, layout, isSelected } = props
  const selectedSeries = series.find((s) =>
    s.groups.some((g) => g.options.some(isSelected))
  )
  const [seriesKey, setSeries] = useState(selectedSeries?.key)
  const [groupKey, setGroup] = useState<string>()
  const [query, setQuery] = useState('')
  const [browse, setBrowse] = useState(!selectedSeries)
  const panel = useRef<HTMLDivElement>(null)
  const needle = query.trim().toLocaleLowerCase()
  const visible = !needle
    ? series
    : series.flatMap((s) => {
        if (s.label.toLocaleLowerCase().includes(needle)) return [s]
        const groups = s.groups.flatMap((g) => {
          if (g.label.toLocaleLowerCase().includes(needle)) return [g]
          const options = g.options.filter((o) =>
            props
              .keywords(o)
              .some((k) => k.toLocaleLowerCase().includes(needle))
          )
          return options.length ? [{ ...g, options }] : []
        })
        return groups.length ? [{ ...s, groups }] : []
      })
  const current = visible.find((s) => s.key === seriesKey) ?? visible[0]
  const group =
    current?.groups.find((g) => g.key === groupKey) ??
    current?.groups.find((g) => g.options.some(isSelected)) ??
    current?.groups[0]
  const media = layout === 'media'
  let options = current?.groups ?? []
  if (layout === 'variants') options = visible.flatMap((s) => s.groups)
  if (media) options = group ? [group] : []
  function focusPane(name: string) {
    requestAnimationFrame(() => {
      const area = panel.current?.querySelector<HTMLElement>(
        `[data-pane="${name}"]`
      )
      const target =
        area?.querySelector<HTMLElement>(
          'button[aria-pressed="true"]:not(:disabled),button[aria-selected="true"]:not(:disabled)'
        ) ??
        area?.querySelector<HTMLElement>(
          'button:not(:disabled):not(.ow-picker-back)'
        )
      target?.focus({ preventScroll: true })
    })
  }
  function keys(event: KeyboardEvent) {
    const target = event.target as HTMLElement
    const input = target.tagName === 'INPUT'
    if (input && event.key !== 'ArrowDown') return
    const area = target.closest<HTMLElement>('[data-pane]')
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      const panes = {
        text: ['models', 'variants'],
        media: ['series', 'models', 'variants'],
        variants: ['variants'],
      }[layout]
      const next =
        panes[
          panes.indexOf(area?.dataset.pane ?? '') +
            (event.key === 'ArrowRight' ? 1 : -1)
        ]
      if (next) {
        event.preventDefault()
        setBrowse(next === 'models')
        focusPane(next)
      }
      return
    }
    if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return
    const items =
      (area ?? panel.current)?.querySelectorAll<HTMLButtonElement>(
        'button:not(:disabled):not(.ow-picker-back)'
      ) ?? []
    const buttons = [...items].filter(
      (button) => button.getClientRects().length
    )
    if (!buttons.length) return
    event.preventDefault()
    const at = buttons.indexOf(target as HTMLButtonElement)
    const step = event.key === 'ArrowDown' ? 1 : -1
    let index = Math.max(0, Math.min(buttons.length - 1, at + step))
    if (event.key === 'Home') index = 0
    if (event.key === 'End') index = buttons.length - 1
    buttons[index].focus()
  }
  return (
    <div className='ow-picker-panel' ref={panel} onKeyDown={keys}>
      <input
        type='search'
        aria-label={labels.search}
        placeholder={labels.placeholder}
        value={query}
        onChange={(e) => {
          setQuery(e.target.value)
          setBrowse(false)
        }}
      />
      {props.notice}
      {current && media && (
        <nav
          data-pane='series'
          className='ow-picker-series'
          aria-label={labels.series}
        >
          {visible.map((s) => (
            <button
              type='button'
              key={s.key}
              aria-pressed={s.key === current.key}
              onClick={() => {
                setSeries(s.key)
                setGroup(undefined)
                setBrowse(true)
              }}
            >
              {s.icon}
              {s.label}
            </button>
          ))}
        </nav>
      )}
      {current ? (
        <div
          className='ow-picker-panes'
          data-browse={browse}
          data-layout={layout}
        >
          {layout !== 'variants' && (
            <nav
              data-pane='models'
              className='ow-picker-rail'
              aria-label={media ? labels.models : labels.series}
            >
              {(media ? current.groups : visible).map((item) => (
                <button
                  type='button'
                  key={item.key}
                  aria-pressed={item.key === (media ? group?.key : current.key)}
                  onClick={() => {
                    if (media) setGroup(item.key)
                    else setSeries(item.key)
                    setBrowse(false)
                  }}
                >
                  {!media && 'icon' in item && item.icon}
                  <span>{item.label}</span>
                  <span aria-hidden>›</span>
                </button>
              ))}
            </nav>
          )}
          <section
            className='ow-picker-options'
            data-pane='variants'
            aria-label={labels.variants}
          >
            {layout !== 'variants' && (
              <button
                className='ow-picker-back'
                type='button'
                aria-label={labels.back}
                onClick={() => {
                  setBrowse(true)
                  focusPane('models')
                }}
              >
                ‹ {media ? group?.label : current.label}
              </button>
            )}
            <div
              role={props.optionRole ?? 'group'}
              aria-label={labels.variants}
            >
              {options.map((g) => (
                <div key={g.key}>
                  {props.renderGroupHeading?.(g)}
                  {g.options.map((o) => props.renderOption(o, g))}
                </div>
              ))}
            </div>
          </section>
        </div>
      ) : (
        <div className='ow-picker-empty' role='status'>
          {needle ? (labels.noMatches ?? labels.empty) : labels.empty}
        </div>
      )}
    </div>
  )
}
