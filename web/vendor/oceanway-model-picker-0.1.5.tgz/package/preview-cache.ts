// This is display data, not a cached catalog response or an execution capability.
export type PickerPreviewRow = {
  id: number
  model_name: string
  model_type: 'text' | 'image' | 'video'
  model_series?: string
  logical_model?: string
  display_name?: string
  is_default?: boolean
}

export type PickerPreviewScope = {
  product: string
  user: number
  session: string
  workspace: string
}

const maxRows = 128
const maxAge = 24 * 60 * 60 * 1000
const key = (product: string) => `oceanway:picker-preview:v2:${product}`
const scopeID = (s: PickerPreviewScope) =>
  JSON.stringify([s.user, s.session, s.workspace])

function displayRow(row: PickerPreviewRow): PickerPreviewRow | undefined {
  if (
    !row ||
    !Number.isSafeInteger(row.id) ||
    row.id <= 0 ||
    typeof row.model_name !== 'string' ||
    !row.model_name ||
    row.model_name.length > 256 ||
    !['text', 'image', 'video'].includes(row.model_type)
  ) {
    return
  }
  const label = (s?: string) =>
    typeof s === 'string' && s ? s.slice(0, 256) : undefined
  return {
    id: row.id,
    model_name: row.model_name,
    model_type: row.model_type,
    model_series: label(row.model_series),
    logical_model: label(row.logical_model),
    display_name: label(row.display_name),
    is_default: row.is_default === true,
  }
}

export function clearPickerPreview(product: string) {
  try {
    localStorage.removeItem(key(product))
  } catch {
    /* Storage is optional. */
  }
}

export function writePickerPreview(
  scope: PickerPreviewScope,
  rows: PickerPreviewRow[]
) {
  if (!(scope.user > 0) || !scope.session || !scope.product) return
  try {
    // Keep preferences reachable even for a large catalog.
    const selected = [
      ...rows.filter((row) => row.is_default),
      ...rows.filter((row) => !row.is_default),
    ]
    const items = selected.slice(0, maxRows).map(displayRow).filter(Boolean)
    localStorage.setItem(
      key(scope.product),
      JSON.stringify({
        scope: scopeID(scope),
        saved: Date.now(),
        items,
      })
    )
  } catch {
    /* A storage quota or disabled storage must not break the picker. */
  }
}

export function readPickerPreview(
  scope: PickerPreviewScope
): PickerPreviewRow[] {
  try {
    if (!(scope.user > 0) || !scope.session || !scope.product) return []
    const raw = localStorage.getItem(key(scope.product))
    if (!raw || raw.length > 256 * 1024) return []
    const value = JSON.parse(raw)
    const age = Date.now() - value.saved
    if (
      value.scope !== scopeID(scope) ||
      !Number.isFinite(age) ||
      age < 0 ||
      age >= maxAge ||
      !Array.isArray(value.items) ||
      value.items.length > maxRows
    ) {
      return []
    }
    return value.items.flatMap(
      (rawRow: PickerPreviewRow) => displayRow(rawRow) ?? []
    )
  } catch {
    return []
  }
}
