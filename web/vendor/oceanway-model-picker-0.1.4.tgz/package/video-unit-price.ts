export type VideoPriceSettings = {
  resolution?: string
  ratio?: string
  referenceSeconds?: number
  seconds?: number
  videoReference: boolean
}

export function videoPriceSettings(
  parameters: Record<string, unknown>,
  videoReference: boolean,
  referenceSeconds?: number
): VideoPriceSettings {
  const resolution =
    parameters['/resolution'] ??
    parameters['/metadata/resolution'] ??
    parameters.resolution
  const ratio =
    parameters['/metadata/aspect_ratio'] ??
    parameters['/ratio'] ??
    parameters['/aspect_ratio'] ??
    parameters.ratio ??
    parameters.aspect_ratio
  const duration =
    parameters['/duration'] ?? parameters.duration ?? parameters.seconds
  return {
    resolution: typeof resolution === 'string' ? resolution : undefined,
    ratio: typeof ratio === 'string' ? ratio : undefined,
    referenceSeconds,
    seconds: duration === undefined ? undefined : Number(duration),
    videoReference,
  }
}

type PriceRange = {
  min: string
  max: string
  dimension: string
  rate_unit: string
  conditions?: { specification: Record<string, unknown>; amount: string }[]
}

type VideoPriceModel = {
  model_type?: string
  media_generation_profile?: unknown
  presentation?: { price_summary: PriceRange[] }
  price?: { status: string }
}

// Output dimensions published in the Ark create-video-generation-task API.
type Grid = Record<string, readonly [number, number]>
const grids: Record<string, Grid> = {
  '480p': {
    '16:9': [864, 496],
    '4:3': [752, 560],
    '1:1': [640, 640],
    '21:9': [992, 432],
  },
  '720p': {
    '16:9': [1280, 720],
    '4:3': [1112, 834],
    '1:1': [960, 960],
    '21:9': [1470, 630],
  },
  '1080p': {
    '16:9': [1920, 1080],
    '4:3': [1664, 1248],
    '1:1': [1440, 1440],
    '21:9': [2206, 946],
  },
  '4k': {
    '16:9': [3840, 2160],
    '4:3': [3326, 2494],
    '1:1': [2880, 2880],
    '21:9': [4398, 1886],
  },
}

function outputDimensions(template: string, resolution: string, ratio: string) {
  let grid = grids[resolution]
  if (
    !grid ||
    (resolution === '4k' && template !== 'seedance-2.0') ||
    (resolution === '1080p' &&
      ['seedance-2.0-fast', 'seedance-2.0-mini'].includes(template))
  )
    return
  if (resolution === '480p' && template === 'seedance-2.5')
    grid = { ...grid, '16:9': [854, 480] }
  if (ratio === 'adaptive')
    return Object.values(grid).reduce((a, b) =>
      a[0] * a[1] >= b[0] * b[1] ? a : b
    )
  if (ratio === '9:16' || ratio === '3:4') {
    const [width, height] = grid[ratio === '9:16' ? '16:9' : '4:3']
    return [height, width] as const
  }
  return grid[ratio]
}

export type VideoUnitQuote = { tokens: number; points: string }

export function seedanceDisplayPrice(
  model: VideoPriceModel,
  settings?: VideoPriceSettings,
  quote?: VideoUnitQuote
) {
  const profile = model.media_generation_profile as
    | {
        defaults?: Record<string, unknown>
        native_request_profile?: {
          capabilities?: {
            template_id?: string
            parameters?: { duration?: { schema?: { enum?: number[] } } }
          }
        }
      }
    | undefined
  const capability = profile?.native_request_profile?.capabilities
  const template = capability?.template_id ?? ''
  if (
    model.model_type !== 'video' ||
    model.price?.status === 'unavailable' ||
    ![
      'seedance-2.0',
      'seedance-2.5',
      'seedance-2.0-fast',
      'seedance-2.0-mini',
    ].includes(template)
  )
    return
  const ranges = model.presentation?.price_summary ?? []
  if (
    !ranges.length ||
    !ranges.every(
      (range) =>
        range.rate_unit === 'million_tokens' &&
        range.dimension === 'completion_tokens'
    )
  )
    return
  const defaults = videoPriceSettings(profile?.defaults ?? {}, false)
  const resolution = settings?.resolution ?? defaults.resolution
  const ratio = settings?.ratio ?? defaults.ratio ?? 'adaptive'
  const duration = settings?.seconds ?? defaults.seconds
  const limit = template === 'seedance-2.5' ? 30 : 15
  // With no reference video, the per-second rate is duration-independent except for token rounding.
  const seconds =
    duration === -1 && !settings?.videoReference ? limit : duration
  const videoReference = settings?.videoReference ?? false
  const unavailable = { state: 'unavailable' as const }
  if (
    !seconds ||
    !Number.isSafeInteger(seconds) ||
    seconds < 4 ||
    seconds > limit ||
    (capability?.parameters?.duration?.schema?.enum &&
      !capability.parameters.duration.schema.enum.includes(duration ?? seconds))
  )
    return unavailable
  const grid =
    resolution && outputDimensions(template, resolution.toLowerCase(), ratio)
  if (!grid) return unavailable
  const conditions = ranges.flatMap((range) => range.conditions ?? [])
  const videoInput = videoReference ? 'video' : 'none'
  const rates = new Set(
    conditions
      .filter(({ specification: spec }) =>
        Object.entries(spec ?? {}).every(
          ([key, value]) =>
            (key === 'resolution' && value === resolution) ||
            (key === 'video_input' && value === videoInput)
        )
      )
      .map((condition) => condition.amount)
  )
  if (rates.size !== 1) return unavailable
  const rate = [...rates][0]
  if (!/^\d+(\.\d+)?$/.test(rate)) return unavailable
  const [width, height] = grid
  const referenceSeconds = videoReference ? settings?.referenceSeconds : 0
  if (
    referenceSeconds !== undefined &&
    (!Number.isFinite(referenceSeconds) ||
      referenceSeconds < 0 ||
      referenceSeconds > limit ||
      (videoReference && referenceSeconds === 0))
  )
    return unavailable
  if (!quote && referenceSeconds === undefined) return unavailable
  const tokens =
    quote?.tokens ??
    Math.ceil(
      (width * height * 24 * (seconds + (referenceSeconds ?? 0))) / 1024
    )
  if (!Number.isSafeInteger(tokens) || tokens < 1) return unavailable
  const points = quote
    ? Number(quote.points)
    : (tokens * Number(rate)) / 1_000_000
  const perSecond = points / seconds
  if (!Number.isFinite(perSecond)) return unavailable
  return {
    state: 'estimated' as const,
    width,
    height,
    resolution,
    seconds,
    tokens,
    referenceSeconds,
    ratio,
    autoDuration: duration === -1,
    rate,
    videoReference,
    perSecond: new Intl.NumberFormat('en', {
      useGrouping: false,
      maximumSignificantDigits: 6,
    }).format(perSecond),
  }
}
